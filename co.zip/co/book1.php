<?php include('header.php'); ?>

<div class="min-h-screen bg-gray-900 text-white">
    <div class="max-w-4xl mx-auto p-6 bg-gray-800 rounded-lg shadow-lg">
        <h1 class="text-center text-2xl md:text-3xl font-bold text-blue-400 mb-4">
            Digital Edge: Mastering the Mindset for Online Business Success
        </h1>
        <img src="/co/images/book1.png" alt="Digital Edge Book Cover" class="w-full max-w-md mx-auto rounded-lg mb-6">
        
        <p class="text-lg text-gray-300 mb-4">
            <strong><em>Digital Edge: Mastering the Mindset for Online Business Success</em></strong> is more than just a book—it’s your ultimate guide to thriving in today’s digital economy. Whether you’re an aspiring entrepreneur, a seasoned professional, or someone looking to make a lasting impact online, this book equips you with the tools, strategies, and mindset needed to excel in any online business endeavor.
        </p>
        
        <p class="text-lg text-gray-300 mb-4">
            In a world driven by advanced technology and limitless opportunities, <strong>Digital Edge</strong> reveals how anyone—regardless of background, experience, or resources—can harness the power of the internet to achieve their goals. It’s not just about running a business; it’s about building a presence that attracts leads, commands authority, and delivers measurable results.
        </p>
        
        <h2 class="text-xl md:text-2xl font-semibold text-blue-400 mt-6 mb-4">Free Booklet for the First 1,000 Requests</h2>
        <p class="text-lg text-gray-300 mb-4">
            Get a complimentary booklet of <strong>Digital Edge</strong> that provides a well-crafted introduction to the book and gives you a taste of the transformational content inside. This booklet is packed with valuable insights and actionable advice to get you started on your journey to online business success.
        </p>
        <p class="text-lg text-gray-300 mb-4">
            This offer is exclusively available to the first 1,000 people who request the booklet. You can request your copy via WhatsApp by sending a preformatted message to <span class="text-blue-400 font-semibold">+2347081169661</span>. Don’t miss this opportunity to gain a sneak peek of the book that’s changing lives.
        </p>
        <div class="flex justify-center mt-6">
            <a href="https://wa.me/2347081169661?text=Hello%2C%20I%20am%20interested%20in%20receiving%20the%20free%20booklet%20for%20%22Digital%20Edge%3A%20Mastering%20the%20Mindset%20for%20Online%20Business%20Success.%22%20Thank%20you."
                class="bg-green-500 text-white font-semibold px-6 py-2 rounded-lg hover:bg-green-600 transition">
                <i class="fab fa-whatsapp"></i> Request Booklet
            </a>
        </div>
        
        <h2 class="text-xl md:text-2xl font-semibold text-blue-400 mt-6 mb-4">What This Book Covers:</h2>
        <ul class="list-disc list-inside text-lg text-gray-300 space-y-2 mb-4">
            <li><strong>Build the Right Mindset:</strong> Success begins in the mind. Learn how to overcome fear, develop resilience, and cultivate the confidence needed to take bold steps in the online space.</li>
            <li><strong>Launch with Confidence:</strong> Discover practical, straightforward methods to start your online business, even with limited resources. Avoid common pitfalls and position yourself for success from day one.</li>
            <li><strong>Grow and Scale Your Business:</strong> From generating leads to creating lasting relationships with customers, this book outlines proven strategies to ensure your business flourishes.</li>
            <li><strong>Master Advanced Tools and Technology:</strong> Explore cutting-edge tools and platforms that can save time, reduce costs, and amplify your impact.</li>
            <li><strong>Build a Magnetic Online Presence:</strong> Whether you’re working independently or as part of an organization, learn how to establish a brand that stands out and keeps you ahead of the competition.</li>
        </ul>
        
        <p class="text-lg text-gray-300 mb-4">
            What sets <strong>Digital Edge</strong> apart is its practical approach. Each chapter is designed to deliver immediate value, with actionable advice, real-world examples, and inspiring case studies. Whether you’re starting small or aiming to dominate your niche, the lessons in this book are adaptable to your unique goals and circumstances.
        </p>
        
        <h2 class="text-xl md:text-2xl font-semibold text-blue-400 mt-6 mb-4">Who Is This Book For?</h2>
        <ul class="list-disc list-inside text-lg text-gray-300 space-y-2 mb-4">
            <li>Entrepreneurs looking to build and grow their online businesses.</li>
            <li>Professionals seeking to enhance their digital skills and stand out in competitive markets.</li>
            <li>Freelancers, creatives, and influencers aiming to monetize their talents and reach larger audiences.</li>
            <li>Anyone ready to take control of their financial future and leverage the power of online opportunities.</li>
        </ul>
        
        <h2 class="text-xl md:text-2xl font-semibold text-blue-400 mt-6 mb-4">Why You Need This Book</h2>
        <p class="text-lg text-gray-300 mb-4">
            The digital age is full of opportunities, but without the right knowledge and mindset, you risk being left behind. <strong>Digital Edge</strong> equips you with everything you need to thrive in this ever-changing landscape. It’s a complete toolkit for building the life you’ve always wanted—whether that’s financial independence, professional growth, or personal fulfillment.
        </p>
        
        <p class="text-center text-lg font-bold text-blue-400 mt-6">
            Your journey starts here. Are you ready to step into your future?
        </p>
        
        <div class="flex justify-center mt-6 space-x-4">
            <a href="https://selar.co/334613" class="bg-blue-500 text-white font-semibold px-6 py-2 rounded-lg hover:bg-blue-600 transition">
                <i class="fas fa-shopping-cart"></i> Buy Now
            </a>
            <a href="#" class="bg-gray-600 text-white font-semibold px-6 py-2 rounded-lg hover:bg-gray-700 transition">
                <i class="fas fa-info-circle"></i> Learn More
            </a>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>